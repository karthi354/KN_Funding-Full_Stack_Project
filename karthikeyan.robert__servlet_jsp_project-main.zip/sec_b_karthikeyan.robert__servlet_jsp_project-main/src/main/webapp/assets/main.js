// const profiles = [
//     {
//       href: "../project/After_login_pages/after_login_inside_profile/AL_inside_profile_1.html",
//       image: "../project/assets/images/story_1.jpg",
//       pf_text_1: "FUNDED",
//       pf_text_2: " $1234",
//       persentage: "25%",
//       pb_text_1: "BACKERS ",
//       pb_text_2: "3",
//       content_head: "Help Sportsman Adithya Who Was Stabbed Multiple Times",
//       content:
//         "Adhitya was attacked by unidentified man, thereby stopping his advancement in sports.He is admitted for the prosthetic nose treatment and with your support will undergo nose reconstruction later.Please help and share the link.",
//       days_left: "10 DAYS TO GO",
//     },
//     {
//       href: "../project/After_login_pages/after_login_inside_profile/AL_inside_profile_2.html",
//       image: "../project/assets/images/story_2.jpg",
//       pf_text_1: "FUNDED",
//       pf_text_2: " $4321",
//       persentage: "4%",
//       pb_text_1: "BACKERS ",
//       pb_text_2: "5",
//       content_head: "Liver Transplantation",
//       content: "90% of my liver got damaged. Urgent need of treatment.",
//       days_left: "20 DAYS TO GO",
//     },
//     {
//       href: "../project/After_login_pages/after_login_inside_profile/AL_inside_profile_3.html",
//       image: "../project/assets/images/story_3.jpg",
//       pf_text_1: "FUNDED",
//       pf_text_2: " $5321",
//       persentage: "6%",
//       pb_text_1: "BACKERS ",
//       pb_text_2: "8",
//       content_head: "Help 7 Years Old Ritanya to live her life",
//       content:
//         "Ritanya De Sarkar, a 7 year old little angel is suffering from ALL B Type Leukemia need Bone Marrow transplant on urgent basis.",
//       days_left: "30 DAYS TO GO",
//     },
//     {
//       href: "../project/After_login_pages/after_login_inside_profile/AL_inside_profile_4.html",
//       image: "../project/assets/images/story_4.jpg",
//       pf_text_1: "FUNDED",
//       pf_text_2: " $1234",
//       persentage: "1%",
//       pb_text_1: "BACKERS ",
//       pb_text_2: "3",
//       content_head: "Help Sportsman Adithya Who Was Stabbed Multiple Times",
//       content:
//         " We adopt the deserted seniors and provide them shelter, food, medicare and personal care and attention. We provide food and medical assistance to the lonely seniors and rescue & rehabilitate the vulnerable people. Pls support us with generous donations",
//       days_left: "10 DAYS TO GO",
//     },
//     {
//       href: "../project/After_login_pages/after_login_inside_profile/AL_inside_profile_5.html",
//       image: "../project/assets/images/story_5.jpg",
//       pf_text_1: "FUNDED",
//       pf_text_2: " $4321",
//       persentage: "4%",
//       pb_text_1: "BACKERS ",
//       pb_text_2: "5",
//       content_head: "Liver Transplantation",
//       content:
//         "Help Sri Gokula Krishna Gaushala provide these rescued cows & bulls with proper food shelter & medical care. The contributions will be used to get them fodder & medicines on a regular basis & to take in more rescued cows.",
//       days_left: "20 DAYS TO GO",
//     },
//     {
//       href: "../project/After_login_pages/after_login_inside_profile/AL_inside_profile_6.html",
//       image: "../project/assets/images/story_6.jpg",
//       pf_text_1: "FUNDED",
//       pf_text_2: " $5321",
//       persentage: "6%",
//       pb_text_1: "BACKERS ",
//       pb_text_2: "8",
//       content_head: "Help Vidit feed 3000+ Stray dogs & cows everyday",
//       content:
//         "Help Vidit feed thousands of hungry stray animals everyday & also provide medical care to them. Donate generously to help him feed as many animals as possible.",
//       days_left: "30 DAYS TO GO",
//     },
//   ];

  
// const show_cart = JSON.parse(localStorage.getItem("Request_list"));

// if (!show_cart) {
//     localStorage.setItem("Request_list", JSON.stringify(profiles));
//   }