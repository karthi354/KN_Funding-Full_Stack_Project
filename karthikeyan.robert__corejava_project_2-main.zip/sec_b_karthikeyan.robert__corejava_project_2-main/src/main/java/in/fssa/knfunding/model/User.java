package in.fssa.knfunding.model;

public class User extends UserEntity{

	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(int int1, String string, String string2) {
		// TODO Auto-generated constructor stub
	}
}